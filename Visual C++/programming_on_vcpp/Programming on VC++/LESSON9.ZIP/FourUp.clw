; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CFourUpDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "FourUp.h"

ClassCount=3
Class1=CFourUpApp
Class2=CFourUpDlg
Class3=CAboutDlg

ResourceCount=5
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDD_FOURUP_DIALOG
Resource4=IDD_ABOUTBOX (English (U.S.))
Resource5=IDD_FOURUP_DIALOG (English (U.S.))

[CLS:CFourUpApp]
Type=0
HeaderFile=FourUp.h
ImplementationFile=FourUp.cpp
Filter=N

[CLS:CFourUpDlg]
Type=0
HeaderFile=FourUpDlg.h
ImplementationFile=FourUpDlg.cpp
Filter=D
LastObject=IDC_CARD3
BaseClass=CDialog
VirtualFilter=dWC

[CLS:CAboutDlg]
Type=0
HeaderFile=FourUpDlg.h
ImplementationFile=FourUpDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg


[DLG:IDD_FOURUP_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CFourUpDlg

[DLG:IDD_FOURUP_DIALOG (English (U.S.))]
Type=1
Class=CFourUpDlg
ControlCount=14
Control1=IDCANCEL,button,1342242816
Control2=IDC_DEALCARDS,button,1342242816
Control3=IDC_CARD1,static,1342177283
Control4=IDC_CARD2,static,1342177283
Control5=IDC_CARD3,static,1342177283
Control6=IDC_CARD4,static,1342177283
Control7=IDC_AMT_LEFT,button,1342177287
Control8=IDC_STATIC,static,1342177283
Control9=IDC_STAT,static,1342177294
Control10=IDC_STATIC,button,1342177287
Control11=IDC_STATIC,static,1342308352
Control12=IDC_STATIC,static,1342308352
Control13=IDC_STATIC,static,1342308352
Control14=IDC_STATIC,static,1342308352

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=6
Control1=IDC_STATIC,static,1342308865
Control2=IDC_OK,button,1342242816
Control3=IDC_STATIC,static,1342308865
Control4=IDC_STATIC,static,1342177283
Control5=IDC_STATIC,static,1342177294
Control6=IDC_STATIC,button,1342177287

