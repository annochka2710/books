// FourUpDlg.h : header file
//

#if !defined(AFX_FOURUPDLG_H__B34449E8_7C19_11D3_8B0F_F3CD66E05218__INCLUDED_)
#define AFX_FOURUPDLG_H__B34449E8_7C19_11D3_8B0F_F3CD66E05218__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CFourUpDlg dialog

class CFourUpDlg : public CDialog
{
// Construction
	private:
		HINSTANCE bit;
		HBITMAP bitmap;
		int m_Cards[4];
		double m_Amt_Remaining;

public:
	HICON& PickRandomCard();
	void CalculateWinnings();
	void DealCards();
	CFourUpDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CFourUpDlg)
	enum { IDD = IDD_FOURUP_DIALOG };
	CStatic	m_Bitmap;
	CStatic	m_Card4;
	CStatic	m_Card3;
	CStatic	m_Card2;
	CStatic	m_Card1;
	CButton	m_Amt_Left;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFourUpDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:

	HICON m_hIcon;
	HICON m_Club;
	HICON m_Diamond;
	HICON m_Heart;
	HICON m_Spade;


	// Generated message map functions
	//{{AFX_MSG(CFourUpDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnCancel();
	afx_msg void OnDealcards();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOURUPDLG_H__B34449E8_7C19_11D3_8B0F_F3CD66E05218__INCLUDED_)
