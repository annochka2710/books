//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FourUp.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FOURUP_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDI_HEART                       131
#define IDI_CLUB                        132
#define IDI_DIAMOND                     133
#define IDI_SPADE                       134
#define IDB_BITMAP1                     136
#define IDB_BITMAP2                     140
#define IDC_OK                          1000
#define IDC_DEALCARDS                   1001
#define IDC_CARD1                       1008
#define IDC_CARD2                       1009
#define IDC_CARD3                       1010
#define IDC_CARD4                       1011
#define IDC_AMT_LEFT                    1012
#define IDC_STAT                        1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
