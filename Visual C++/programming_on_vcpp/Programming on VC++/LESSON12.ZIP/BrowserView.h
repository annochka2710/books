// BrowserView.h : interface of the CBView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_BROWSERVIEW_H__6557DD0D_852B_11D1_8B13_FBB823A7A24B__INCLUDED_)
#define AFX_BROWSERVIEW_H__6557DD0D_852B_11D1_8B13_FBB823A7A24B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CBView : public CHtmlView
{
protected: // create from serialization only
	CBView();
	DECLARE_DYNCREATE(CBView)

// Attributes
public:
	CBDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnDocumentComplete(LPCTSTR lpszURL);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CBView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CBView)
	afx_msg void OnWebBack();
	afx_msg void OnWebForward();
	afx_msg void OnWebOpen();
	afx_msg void OnWebSearch();
	afx_msg void OnWebStop();
	afx_msg void OnFileOpen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CFileDialog m_FileDialog;
};

#ifndef _DEBUG  // debug version in BrowserView.cpp
inline CBDoc* CBView::GetDocument()
   { return (CBDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BROWSERVIEW_H__6557DD0D_852B_11D1_8B13_FBB823A7A24B__INCLUDED_)
