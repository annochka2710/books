#if !defined(AFX_URLDLG_H__6557DD15_852B_11D1_8B13_FBB823A7A24B__INCLUDED_)
#define AFX_URLDLG_H__6557DD15_852B_11D1_8B13_FBB823A7A24B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// URLDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CURLDlg dialog

class CURLDlg : public CDialog
{
// Construction
public:
	CURLDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CURLDlg)
	enum { IDD = IDD_OPEN_WEB };
	CString	m_URL;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CURLDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CURLDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_URLDLG_H__6557DD15_852B_11D1_8B13_FBB823A7A24B__INCLUDED_)
