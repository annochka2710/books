// BrowserView.cpp : implementation of the CBView class
//

#include "stdafx.h"
#include "Browser.h"

#include "BrowserDoc.h"
#include "BrowserView.h"
#include "URLDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBView

IMPLEMENT_DYNCREATE(CBView, CHtmlView)

BEGIN_MESSAGE_MAP(CBView, CHtmlView)
	//{{AFX_MSG_MAP(CBView)
	ON_COMMAND(ID_WEB_BACK, OnWebBack)
	ON_COMMAND(ID_WEB_FORWARD, OnWebForward)
	ON_COMMAND(ID_WEB_OPEN, OnWebOpen)
	ON_COMMAND(ID_WEB_SEARCH, OnWebSearch)
	ON_COMMAND(ID_WEB_STOP, OnWebStop)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CHtmlView::OnFilePrint)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBView construction/destruction

CBView::CBView()
:m_FileDialog(TRUE, "*.html", "*.html", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "HTML Files (*.html)  |*.html;*.html||")
{
	// TODO: add construction code here

//if(m_FileDialog.DoModal()==IDOK)Navigate2(m_FileDialog.GetPAthNAme(), NULL, NULL);
}

CBView::~CBView()
{
}

BOOL CBView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CHtmlView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CBView drawing

void CBView::OnDraw(CDC* pDC)
{
	CBDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CBView::OnInitialUpdate()
{
	CHtmlView::OnInitialUpdate();

	// TODO: This code navigates to a popular spot on the web.
	//  change the code to go where you'd like.
	/*char drive[_MAX_PATH];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	_splitpath(__argv[0], drive, dir, fname, ext);
	CString path(drive);

	path+=dir;
	path+="Browser.html";

	Navigate2(path,NULL,NULL);*/
	LoadFromResource(IDR_HOME);

}

/////////////////////////////////////////////////////////////////////////////
// CBView printing


/////////////////////////////////////////////////////////////////////////////
// CBView diagnostics

#ifdef _DEBUG
void CBView::AssertValid() const
{
	CHtmlView::AssertValid();
}

void CBView::Dump(CDumpContext& dc) const
{
	CHtmlView::Dump(dc);
}

CBDoc* CBView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CBDoc)));
	return (CBDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBView message handlers

void CBView::OnWebBack() 
{
	// TODO: Add your command handler code here
	GoBack();
}

void CBView::OnWebForward() 
{
	// TODO: Add your command handler code here
	GoForward();
}

void CBView::OnWebOpen() 
{
	// TODO: Add your command handler code here
CURLDlg 	dlg;
if(dlg.DoModal()==IDOK)Navigate2(dlg.m_URL,NULL, NULL);
}

void CBView::OnWebSearch() 
{
	// TODO: Add your command handler code here
	GoSearch();
}

void CBView::OnWebStop() 
{
	// TODO: Add your command handler code here
	Stop();
}

void CBView::OnDocumentComplete(LPCTSTR lpszURL) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CHtmlView::OnDocumentComplete(lpszURL);
	AfxGetMainWnd()->SetWindowText(GetLocationName());
	(GetDocument())->m_URL=lpszURL;
}

void CBView::OnFileOpen() 
{
	// TODO: Add your command handler code here
	if(m_FileDialog.DoModal()==IDOK)
	{
		Navigate2(m_FileDialog.GetPathName(), NULL, NULL);
	}
}
