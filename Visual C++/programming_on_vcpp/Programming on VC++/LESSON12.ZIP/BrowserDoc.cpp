// BrowserDoc.cpp : implementation of the CBDoc class
//

#include "stdafx.h"
#include "Browser.h"
#include <afxinet.h>


#include "BrowserDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBDoc

IMPLEMENT_DYNCREATE(CBDoc, CDocument)

BEGIN_MESSAGE_MAP(CBDoc, CDocument)
	//{{AFX_MSG_MAP(CBDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBDoc construction/destruction

CBDoc::CBDoc()
{
	// TODO: add one-time construction code here

}

CBDoc::~CBDoc()
{
}

BOOL CBDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CBDoc serialization
const MAX_BUF=1024;
void CBDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
		if(m_URL.Left(4)=="res:")
		{
			AfxMessageBox("Cannot save internal HTML file");
			return;
		}
		if(!m_URL.IsEmpty())
		{
			char buf[MAX_BUF];
			CInternetSession session;
			CStdioFile *pFile =NULL;
			pFile=session.OpenURL(m_URL);
			int nBytesRead;
			while((nBytesRead=pFile->Read(buf,MAX_BUF))>0)
			{
				ar.Write(buf, nBytesRead);
			}
			delete pFile;
			session.Close();
		}
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CBDoc diagnostics

#ifdef _DEBUG
void CBDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CBDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBDoc commands
