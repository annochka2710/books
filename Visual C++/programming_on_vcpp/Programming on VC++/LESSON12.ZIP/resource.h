//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Browser.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_BROWSETYPE                  129
#define IDR_HOME                        131
#define IDD_OPEN_WEB                    132
#define IDC_URL                         1000
#define ID_BUTTON32772                  32772
#define ID_BUTTON32773                  32773
#define ID_BUTTON32774                  32774
#define ID_BACK                         32775
#define ID_BUTTON32776                  32776
#define ID_WEB_FORWARD                  32777
#define ID_WEB_BACK                     32778
#define ID_WEB_STOP                     32779
#define ID_WEB_OPEN                     32780
#define ID_WEB_SEARCH                   32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
