// Browser.h : main header file for the BROWSER application
//

#if !defined(AFX_BROWSER_H__6557DD05_852B_11D1_8B13_FBB823A7A24B__INCLUDED_)
#define AFX_BROWSER_H__6557DD05_852B_11D1_8B13_FBB823A7A24B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CBApp:
// See Browser.cpp for the implementation of this class
//

class CBApp : public CWinApp
{
public:
	CBApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CBApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BROWSER_H__6557DD05_852B_11D1_8B13_FBB823A7A24B__INCLUDED_)
