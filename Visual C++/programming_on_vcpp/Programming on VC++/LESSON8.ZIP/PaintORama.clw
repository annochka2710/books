; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CPaintORamaDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "PaintORama.h"

ClassCount=2
Class1=CPaintORamaApp
Class2=CPaintORamaDlg

ResourceCount=4
Resource2=IDR_MAINFRAME
Resource3=IDD_PAINTORAMA_DIALOG
Resource4=IDD_PAINTORAMA_DIALOG (English (U.S.))

[CLS:CPaintORamaApp]
Type=0
HeaderFile=PaintORama.h
ImplementationFile=PaintORama.cpp
Filter=N

[CLS:CPaintORamaDlg]
Type=0
HeaderFile=PaintORamaDlg.h
ImplementationFile=PaintORamaDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=CPaintORamaDlg



[DLG:IDD_PAINTORAMA_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CPaintORamaDlg

[DLG:IDD_PAINTORAMA_DIALOG (English (U.S.))]
Type=1
Class=CPaintORamaDlg
ControlCount=24
Control1=IDC_CANVAS,static,1342181384
Control2=IDC_CLEARBTN,button,1342242816
Control3=IDC_STATIC,button,1342308359
Control4=IDC_PENWIDTH,edit,1350631552
Control5=IDC_SPIN1,msctls_updown32,1342177334
Control6=IDC_STATIC,static,1342308352
Control7=IDC_STATIC,static,1342308352
Control8=IDC_PENCOLOR,static,1342181636
Control9=IDC_SOLID_PEN,button,1342308361
Control10=IDC_BRUSHSTYLE,listbox,1352728833
Control11=IDC_STATIC,static,1342308352
Control12=IDC_RADIO2,button,1342177289
Control13=IDC_RADIO5,button,1342177289
Control14=IDC_RADIO6,button,1342177289
Control15=IDC_RADIO7,button,1342177289
Control16=IDC_STATIC,button,1342308359
Control17=IDC_BRUSHCOLOR,static,1342181636
Control18=IDC_STATIC,button,1342177287
Control19=IDC_SHAPES,combobox,1344340227
Control20=IDC_RADIO3,button,1342177289
Control21=IDC_RADIO4,button,1342177289
Control22=IDC_BRUSHPREVIEW,static,1342181636
Control23=IDC_STATIC,static,1342308352
Control24=IDC_STATIC,static,1342308352

