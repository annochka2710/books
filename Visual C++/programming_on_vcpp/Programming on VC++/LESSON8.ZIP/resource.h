//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PaintORama.rc
//
#define IDD_PAINTORAMA_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_CANVAS                      1000
#define IDC_CLEARBTN                    1001
#define IDC_PENWIDTH                    1002
#define IDC_SPIN1                       1003
#define IDC_PENCOLOR                    1005
#define IDC_SOLID_PEN                   1006
#define IDC_RADIO2                      1007
#define IDC_RADIO3                      1008
#define IDC_RADIO4                      1009
#define IDC_RADIO5                      1010
#define IDC_RADIO6                      1011
#define IDC_RADIO7                      1012
#define IDC_SHAPES                      1014
#define IDC_BRUSHSTYLE                  1015
#define IDC_BRUSHCOLOR                  1016
#define IDC_BRUSHPREVIEW                1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
