// PaintORamaDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PaintORama.h"
#include "PaintORamaDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPaintORamaDlg dialog

CPaintORamaDlg::CPaintORamaDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPaintORamaDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPaintORamaDlg)
	m_PenWidth = 0;
	m_PenStyle = -1;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_PenWidth = 1;
	m_PenColor = RGB(0, 0, 0);
		CClientDC dc(this);
	dc.SelectStockObject(NULL_PEN);
	dc.Rectangle(m_Canvas);
	m_PenStyle=PS_INSIDEFRAME;
}

void CPaintORamaDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPaintORamaDlg)
	DDX_Control(pDX, IDC_BRUSHSTYLE, m_BrushStyleList);
	DDX_Control(pDX, IDC_SHAPES, m_ShapesCombo);
	DDX_Text(pDX, IDC_PENWIDTH, m_PenWidth);
	DDV_MinMaxInt(pDX, m_PenWidth, 1, 32);
	DDX_Radio(pDX, IDC_SOLID_PEN, m_PenStyle);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPaintORamaDlg, CDialog)
	//{{AFX_MSG_MAP(CPaintORamaDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CLEARBTN, OnClearbtn)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_BN_CLICKED(IDC_PENCOLOR, OnPencolor)
	ON_LBN_SELCHANGE(IDC_BRUSHSTYLE, OnSelchangeBrushstyle)
	ON_BN_CLICKED(IDC_BRUSHCOLOR, OnBrushcolor)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPaintORamaDlg message handlers

BOOL CPaintORamaDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_IsDrawing=FALSE;
	
	CWnd* p_Canvas=GetDlgItem(IDC_CANVAS);
	p_Canvas->GetWindowRect(&m_Canvas);
	ScreenToClient(&m_Canvas);
	m_Canvas.DeflateRect(2,2,1,1);

	CWnd* pPenColor=GetDlgItem(IDC_PENCOLOR);
	pPenColor->GetWindowRect(&m_PenColorSwatch);
	ScreenToClient(&m_PenColorSwatch);
	m_PenColorSwatch.DeflateRect(2,2,1,1);

	CSpinButtonCtrl* pSpin = (CSpinButtonCtrl*)GetDlgItem(IDC_SPIN1);
	pSpin->SetRange(1,32);
	pSpin->SetPos(1);

	m_ShapesCombo.SetCurSel(0);


	m_BrushStyleList.AddString("(none)");
	m_BrushStyleList.AddString("Solid");
	m_BrushStyleList.AddString("LL-UR Diagonal");
	m_BrushStyleList.AddString("UL-LR Diagonal");
	m_BrushStyleList.AddString("Grid");
	m_BrushStyleList.AddString("Grid Diagonal");
	m_BrushStyleList.AddString("Horizontal");
	m_BrushStyleList.AddString("Vertical");
	m_BrushStyleList.AddString("White");
	m_BrushStyleList.AddString("Light Gray");
	m_BrushStyleList.AddString("Medium Gray");
	m_BrushStyleList.AddString("Dark Gray");
	m_BrushStyleList.AddString("Black");
	m_BrushStyleList.SetCurSel(8);

	CWnd* pBrushColor=GetDlgItem(IDC_BRUSHCOLOR);
	pBrushColor->GetWindowRect(&m_BrushColorSwatch);;
	ScreenToClient(&m_BrushColorSwatch);
	m_BrushColorSwatch.DeflateRect(2,2,1,1);

	CWnd* pPreviewColor= GetDlgItem(IDC_BRUSHPREVIEW);
	pPreviewColor->GetWindowRect(&m_BrushPreviewSwatch);
	ScreenToClient(&m_BrushPreviewSwatch);
	m_BrushPreviewSwatch.DeflateRect(2,2,1,1);
	
	m_BrushColor=RGB(0,0,0);

	m_Brush.CreateSolidBrush(RGB(0,0,0));

	m_pMF = new CMetaFileDC;
	m_pMF->Create();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPaintORamaDlg::OnPaint() 
{
CPaintDC dc(this);


HMETAFILE hmf=m_pMF->Close();
dc.PlayMetaFile(hmf);
CMetaFileDC* temp=new CMetaFileDC;
temp->Create();
temp->PlayMetaFile(hmf);

DeleteMetaFile(hmf);
delete hmf;

m_pMF=temp; 
static firstTime=TRUE;
if(firstTime)
{
	OnClearbtn();
	firstTime=FALSE;
}


}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPaintORamaDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CPaintORamaDlg::OnClearbtn() 
{
	// TODO: Add your control notification handler code here
	CClientDC dc(this);
	HMETAFILE hmf=m_pMF->Close();
	::DeleteMetaFile(hmf);
	delete hmf;
	m_pMF=new CMetaFileDC;
	m_pMF->Create();
	m_pMF->SetAttribDC(dc);



	dc.SelectStockObject(NULL_PEN);
	dc.Rectangle(m_Canvas);

	m_pMF->SelectStockObject(NULL_PEN);
	m_pMF->Rectangle(m_Canvas.left,m_Canvas.top,
			m_Canvas.right+1,m_Canvas.bottom+1);
}

void CPaintORamaDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_Canvas.PtInRect(point))
	{
		m_IsDrawing=true;
		m_LineStart= point;
		m_LineEnd=point;

		UpdateData(TRUE);
		m_Pen.DeleteObject();
		m_Pen.CreatePen(m_PenStyle, m_PenWidth, m_PenColor);
		SetCapture();
		
	}
	CDialog::OnLButtonDown(nFlags, point);
}

void CPaintORamaDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	m_IsDrawing=FALSE;
	
	if(m_Canvas.PtInRect(point))
	{
	//m_LineEnd=point;
	DrawShape();
	}
	else
	{
		DrawShape(true);
	}
	m_LineStart=point;
	ReleaseCapture();

	CDialog::OnLButtonUp(nFlags, point);
}

void CPaintORamaDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_IsDrawing && (nFlags & MK_LBUTTON) && m_Canvas.PtInRect(point))
	{
	
		DrawShape(true);
		m_LineEnd= point;
		DrawShape(true);
		
	}


	CDialog::OnMouseMove(nFlags, point);
}

void CPaintORamaDlg::OnPencolor() 
{
	// TODO: Add your control notification handler code here
	CColorDialog dlg(m_PenColor);
	if(dlg.DoModal()==IDOK)
	{
		m_PenColor=dlg.GetColor();
		CBrush swatch;
		swatch.CreateSolidBrush(m_PenColor);
		CClientDC dc(this);
		dc.FillRect(&m_PenColorSwatch, &swatch);
	}
}

void CPaintORamaDlg::DrawShape(bool stretch)
{
CClientDC dc(this);
dc.SetAttribDC(dc);
m_pMF->SetAttribDC(dc);
dc.IntersectClipRect(m_Canvas);

m_pMF->IntersectClipRect(m_Canvas);

int drawmode=m_ShapesCombo.GetCurSel();

dc.SelectObject(&m_Pen);
dc.SelectObject(&m_Brush);
m_pMF->SelectObject(&m_Pen);
m_pMF->SelectObject(&m_Brush);

if(stretch && drawmode!=0)
{
	dc.SetROP2(R2_NOT);
	dc.SetBkMode(TRANSPARENT);
	
}


switch(drawmode)
{
case 0:
	dc.MoveTo(m_LineStart);
	dc.LineTo(m_LineEnd);
	m_pMF->MoveTo(m_LineStart);
	m_pMF->LineTo(m_LineEnd);
	m_LineStart=m_LineEnd;
	break;

case 1:
	dc.MoveTo(m_LineStart);
	dc.LineTo(m_LineEnd);
	if(!stretch)
	{
	m_pMF->MoveTo(m_LineStart);
	m_pMF->LineTo(m_LineEnd);
	}
	break;

case 2:
	dc.Ellipse(CRect(m_LineStart,m_LineEnd));
	if(!stretch)
	{
	m_pMF->Ellipse(CRect(m_LineStart,m_LineEnd));
	
	}
	break;

case 3:
	dc.Rectangle(CRect(m_LineStart,m_LineEnd));
		if(!stretch)
	{
	m_pMF->Rectangle(CRect(m_LineStart,m_LineEnd));
	
	}

	break;
}
}

void CPaintORamaDlg::OnSelchangeBrushstyle() 
{
	// TODO: Add your control notification handler code here
	m_Brush.DeleteObject();
	int style=m_BrushStyleList.GetCurSel();
	switch(style)
	{
	case 0:
		m_Brush.CreateStockObject(NULL_BRUSH);
		break;
	case 1:
		m_Brush.CreateSolidBrush(m_BrushColor);
		break;
	case 2:
		m_Brush.CreateHatchBrush(HS_BDIAGONAL, m_BrushColor);
		break;
	case 3:
		m_Brush.CreateHatchBrush(HS_FDIAGONAL, m_BrushColor);
		break;
	case 4:
		m_Brush.CreateHatchBrush(HS_CROSS, m_BrushColor);
		break;
	case 5:
		m_Brush.CreateHatchBrush(HS_DIAGCROSS, m_BrushColor);
		break;
	case 6:
		m_Brush.CreateHatchBrush(HS_HORIZONTAL, m_BrushColor);
		break;
	case 7:
		m_Brush.CreateHatchBrush(HS_VERTICAL, m_BrushColor);
		break;
	case 9:
		m_Brush.CreateStockObject(LTGRAY_BRUSH);
		break;
		
	case 10:
		m_Brush.CreateStockObject(GRAY_BRUSH);
		break;
	case 11:
		m_Brush.CreateStockObject(DKGRAY_BRUSH);
		break;
	case 12:
		m_Brush.CreateStockObject(BLACK_BRUSH);
		break;
	default:
		m_Brush.CreateStockObject(WHITE_BRUSH);
		break;
		
	}
	PaintBrushPreview();
}

void CPaintORamaDlg::OnBrushcolor() 
{
	// TODO: Add your control notification handler code here
	CColorDialog dlg(m_BrushColor);
	if(dlg.DoModal()==IDOK)
	{
		m_BrushColor=dlg.GetColor();
		CClientDC dc(this);
		CBrush b(m_BrushColor);
		dc.FillRect(&m_BrushColorSwatch,&b);
	}
	OnSelchangeBrushstyle();
}

void CPaintORamaDlg::PaintBrushPreview()
{
CClientDC dc(this);
dc.FillRect(&m_BrushPreviewSwatch,&m_Brush);
}

void CPaintORamaDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	m_pMF->Close();
	delete m_pMF;
}




