// PaintORamaDlg.h : header file
//

#if !defined(AFX_PAINTORAMADLG_H__32CCC287_833D_11D3_8B0F_AA2B68C2B948__INCLUDED_)
#define AFX_PAINTORAMADLG_H__32CCC287_833D_11D3_8B0F_AA2B68C2B948__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPaintORamaDlg dialog

class CPaintORamaDlg : public CDialog
{
// Construction
public:
	void PaintBrushPreview();
	void DrawShape(bool stretch = false);
	CPaintORamaDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CPaintORamaDlg)
	enum { IDD = IDD_PAINTORAMA_DIALOG };
	CListBox	m_BrushStyleList;
	CComboBox	m_ShapesCombo;
	int		m_PenWidth;
	int		m_PenStyle;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPaintORamaDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation


protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CPaintORamaDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClearbtn();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnPencolor();
	afx_msg void OnSelchangeBrushstyle();
	afx_msg void OnBrushcolor();
	afx_msg void OnDestroy();
	afx_msg void OnStat();
	afx_msg void OnUndo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CMetaFileDC* m_pMF;
	CPoint m_LineEnd;
	CRect m_PenColorSwatch;
	CPen m_Pen;
	bool m_IsDrawing;
	CPoint m_LineStart;
	CRect m_Canvas;
	COLORREF m_PenColor;

	CBrush m_Brush;

	COLORREF m_BrushColor;
	int m_BrushStyle;
	CRect m_BrushColorSwatch;
	CRect m_BrushPreviewSwatch;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAINTORAMADLG_H__32CCC287_833D_11D3_8B0F_AA2B68C2B948__INCLUDED_)
