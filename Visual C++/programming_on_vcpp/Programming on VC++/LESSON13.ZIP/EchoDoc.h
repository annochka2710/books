// EchoDoc.h : interface of the CEchoDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ECHODOC_H__0370BD0B_FE82_11D3_8B13_F734BE85D741__INCLUDED_)
#define AFX_ECHODOC_H__0370BD0B_FE82_11D3_8B13_F734BE85D741__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CEchoDoc : public CDocument
{
protected: // create from serialization only
	CEchoDoc();
	DECLARE_DYNCREATE(CEchoDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEchoDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	CString m_TextLine;
	virtual ~CEchoDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CEchoDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ECHODOC_H__0370BD0B_FE82_11D3_8B13_F734BE85D741__INCLUDED_)
