// EchoView.h : interface of the CEchoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ECHOVIEW_H__0370BD0D_FE82_11D3_8B13_F734BE85D741__INCLUDED_)
#define AFX_ECHOVIEW_H__0370BD0D_FE82_11D3_8B13_F734BE85D741__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CEchoView : public CView
{
protected: // create from serialization only
	CEchoView();
	DECLARE_DYNCREATE(CEchoView)

// Attributes
public:
	CEchoDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEchoView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CEchoView();
	POINT m_CaretPos;
	int m_Xcaret,m_Ycaret;
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CEchoView)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnEditClear();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in EchoView.cpp
inline CEchoDoc* CEchoView::GetDocument()
   { return (CEchoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ECHOVIEW_H__0370BD0D_FE82_11D3_8B13_F734BE85D741__INCLUDED_)
