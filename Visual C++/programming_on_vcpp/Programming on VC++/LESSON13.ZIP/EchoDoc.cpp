// EchoDoc.cpp : implementation of the CEchoDoc class
//

#include "stdafx.h"
#include "Echo.h"

#include "EchoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEchoDoc

IMPLEMENT_DYNCREATE(CEchoDoc, CDocument)

BEGIN_MESSAGE_MAP(CEchoDoc, CDocument)
	//{{AFX_MSG_MAP(CEchoDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEchoDoc construction/destruction

CEchoDoc::CEchoDoc()
{
	// TODO: add one-time construction code here

}

CEchoDoc::~CEchoDoc()
{
}

BOOL CEchoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CEchoDoc serialization

void CEchoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CEchoDoc diagnostics

#ifdef _DEBUG
void CEchoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CEchoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CEchoDoc commands
