// EchoView.cpp : implementation of the CEchoView class
//

#include "stdafx.h"
#include "Echo.h"

#include "EchoDoc.h"
#include "EchoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEchoView

IMPLEMENT_DYNCREATE(CEchoView, CView)

BEGIN_MESSAGE_MAP(CEchoView, CView)
	//{{AFX_MSG_MAP(CEchoView)
	ON_WM_CHAR()
	ON_COMMAND(ID_EDIT_CLEAR, OnEditClear)
	ON_WM_CREATE()
	ON_WM_KILLFOCUS()
	ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEchoView construction/destruction

CEchoView::CEchoView()
{
	// TODO: add construction code here
	m_CaretPos.x=m_CaretPos.y=1;
}

CEchoView::~CEchoView()
{
}

BOOL CEchoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CEchoView drawing

void CEchoView::OnDraw(CDC* pDC)
{
	CEchoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDC->SetTextColor(::GetSysColor(COLOR_WINDOWTEXT));
	pDC->SetBkMode(TRANSPARENT);
	pDC->TextOut(1,1, pDoc->m_TextLine);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CEchoView diagnostics

#ifdef _DEBUG
void CEchoView::AssertValid() const
{
	CView::AssertValid();
}

void CEchoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CEchoDoc* CEchoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CEchoDoc)));
	return (CEchoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CEchoView message handlers

void CEchoView::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	CString str;
	CEchoDoc* PDoc=GetDocument();
	if(nChar<32&&nChar!=8)
	{
		::MessageBeep((UINT)-1);
		return;
	}
	CClientDC ClientDC(this);
	ClientDC.SetTextColor(::GetSysColor(COLOR_WINDOWTEXT));
	ClientDC.SetBkMode(TRANSPARENT);
	if(nChar==8)
	{
		str.Format("%d",PDoc->m_TextLine.GetLength());
		if(PDoc->m_TextLine.GetLength()==0)return;
		PDoc->m_TextLine.Delete(PDoc->m_TextLine.GetLength()-1,1);
		PDoc->UpdateAllViews(NULL);
	}

	if(nChar!=8)PDoc->m_TextLine+=nChar;
	CSize Size=ClientDC.GetTextExtent(PDoc->m_TextLine,PDoc->m_TextLine.GetLength());
	HideCaret();
	ClientDC.TextOut(1,1,PDoc->m_TextLine);
	m_CaretPos.x=Size.cx;
	SetCaretPos(m_CaretPos);
	ShowCaret();
	
	CView::OnChar(nChar, nRepCnt, nFlags);

}

void CEchoView::OnEditClear() 
{
	// TODO: Add your command handler code here
	CEchoDoc* pDoc=GetDocument();
	pDoc->m_TextLine.Empty();
	pDoc->UpdateAllViews(NULL);
	m_CaretPos.x=1;
	SetCaretPos(m_CaretPos);
}


int CEchoView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	CClientDC ClientDC(this);
	TEXTMETRIC TM;
	ClientDC.GetTextMetrics(&TM);
	m_Ycaret=::GetSystemMetrics(SM_CXBORDER)*2;
	m_Xcaret=TM.tmHeight+TM.tmExternalLeading;
	return 0;
}

void CEchoView::OnKillFocus(CWnd* pNewWnd) 
{
	CView::OnKillFocus(pNewWnd);
		// TODO: Add your message handler code here
	::DestroyCaret();
}

void CEchoView::OnSetFocus(CWnd* pOldWnd) 
{
	CView::OnSetFocus(pOldWnd);
	CreateSolidCaret(m_Ycaret,m_Xcaret);
	SetCaretPos(m_CaretPos);
	ShowCaret();
	
	// TODO: Add your message handler code here
}
