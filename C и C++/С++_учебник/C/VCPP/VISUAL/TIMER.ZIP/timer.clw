; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CTimerDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "timer.h"

ClassCount=3
Class1=CTimerApp
Class2=CTimerDlg
Class3=CAboutDlg

ResourceCount=5
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDD_TIMER_DIALOG
Resource4=IDD_ABOUTBOX (English (U.S.))
Resource5=IDD_TIMER_DIALOG (English (U.S.))

[CLS:CTimerApp]
Type=0
HeaderFile=timer.h
ImplementationFile=timer.cpp
Filter=N

[CLS:CTimerDlg]
Type=0
HeaderFile=timerDlg.h
ImplementationFile=timerDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=CTimerDlg

[CLS:CAboutDlg]
Type=0
HeaderFile=timerDlg.h
ImplementationFile=timerDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg


[DLG:IDD_TIMER_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CTimerDlg

[DLG:IDD_TIMER_DIALOG (English (U.S.))]
Type=1
Class=CTimerDlg
ControlCount=2
Control1=IDC_BUTTON1,button,1342242816
Control2=IDC_BUTTON2,button,1342242816

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

