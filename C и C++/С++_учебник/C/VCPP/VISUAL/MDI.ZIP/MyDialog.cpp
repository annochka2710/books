// MyDialog.cpp : implementation file
//

#include "stdafx.h"
#include "MDI.h"
#include "MyDialog.h"
#include "MDIDoc.h"
#include "MDIView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyDialog dialog


CMyDialog::CMyDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMyDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyDialog)
	m_DX = 0;
	m_DY = 0;
	m_DXN = 0;
	m_DYN = 0;
	//}}AFX_DATA_INIT
}


void CMyDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyDialog)
	DDX_Text(pDX, IDC_EDIT1_X, m_DX);
	DDX_Text(pDX, IDC_EDIT1_Y, m_DY);
	DDX_Text(pDX, IDC_EDIT2_X, m_DXN);
	DDX_Text(pDX, IDC_EDIT2_Y, m_DYN);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyDialog, CDialog)
	//{{AFX_MSG_MAP(CMyDialog)
	ON_BN_CLICKED(IDC_BUTTON_Ok, OnBUTTONOk)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyDialog message handlers

void CMyDialog::OnBUTTONOk() 
{
	// TODO: Add your control notification handler code here
	OnOK();
}

int CMyDialog::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here


	return 0;
}
