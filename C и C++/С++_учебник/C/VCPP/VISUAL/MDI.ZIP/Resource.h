//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MDI.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MDITYPE                     129
#define IDD_MY_DIALOG                   130
#define IDC_BUTTON_Ok                   1001
#define IDC_EDIT1_X                     1002
#define IDC_MYBUTTON                    1003
#define IDC_EDIT1_Y                     1003
#define IDC_EDIT2_X                     1004
#define IDC_EDIT2_Y                     1005
#define ID_MYBUTTON                     32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
