// MDIDoc.h : interface of the CMDIDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MDIDOC_H__A8D17EAD_92A7_11D3_90D8_0060083232E0__INCLUDED_)
#define AFX_MDIDOC_H__A8D17EAD_92A7_11D3_90D8_0060083232E0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



class CMDIDoc : public CDocument
{
protected: // create from serialization only
	CMDIDoc();
	DECLARE_DYNCREATE(CMDIDoc)

// Attributes
public:

	int m_X;
	int m_Y;
  
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMDIDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMDIDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMDIDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MDIDOC_H__A8D17EAD_92A7_11D3_90D8_0060083232E0__INCLUDED_)
