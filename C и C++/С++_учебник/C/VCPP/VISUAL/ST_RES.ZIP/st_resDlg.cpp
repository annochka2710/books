// st_resDlg.cpp : implementation file
//

#include "stdafx.h"
#include "st_res.h"
#include "st_resDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSt_resDlg dialog

CSt_resDlg::CSt_resDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSt_resDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSt_resDlg)
	m_edit = _T("");
	m_check = FALSE;
	m_radio = TRUE;
	m_text = _T("");
	m_spin_value = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSt_resDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSt_resDlg)
	DDX_Control(pDX, IDC_PROGRESS, m_progress);
	DDX_Control(pDX, IDC_SLIDER, m_slider);
	DDX_Control(pDX, IDC_SPIN, m_spin);
	DDX_Control(pDX, IDC_LIST, m_list);
	DDX_Control(pDX, IDC_COMBO, m_combo);
	DDX_Text(pDX, IDC_EDIT, m_edit);
	DDX_Check(pDX, IDC_CHECK, m_check);
	DDX_Radio(pDX, IDC_RADIO, m_radio);
	DDX_Text(pDX, IDC_EDIT_TEXT, m_text);
	DDX_Text(pDX, IDC_EDIT_SPIN, m_spin_value);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSt_resDlg, CDialog)
	//{{AFX_MSG_MAP(CSt_resDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON, OnButton)
	ON_BN_CLICKED(IDC_CHECK, OnCheck)
	ON_BN_CLICKED(IDC_RADIO, OnRadio)
	ON_CBN_SELCHANGE(IDC_COMBO, OnSelchangeCombo)
	ON_EN_UPDATE(IDC_EDIT_TEXT, OnUpdateEditText)
	ON_LBN_SELCHANGE(IDC_LIST, OnSelchangeList)
	ON_NOTIFY(NM_OUTOFMEMORY, IDC_SPIN, OnOutofmemorySpin)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN, OnDeltaposSpin)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER, OnCustomdrawSlider)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER, OnReleasedcaptureSlider)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSt_resDlg message handlers

BOOL CSt_resDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	

	m_combo.AddString( "COMBO1" );
	m_combo.AddString( "COMBO2" );
	m_combo.AddString( "COMBO3" );
	m_combo.SetCurSel( 0 );
	
	m_list.AddString( "LIST1");
	m_list.AddString( "LIST2");
	m_list.AddString( "LIST2");
	m_list.SetCurSel( 0 );

	m_spin.SetRange32( 0, 100 );
	m_spin.SetPos( 0 );
	m_spin_value = m_spin.GetPos() - 65536;

	m_slider.SetRange( 1, 100, FALSE );
	m_slider.SetTicFreq( 10 );
	m_slider.SetTic( 1 );

	m_progress.SetRange(1, 100 );
	m_progress.SetStep( 5 );

	UpdateData( FALSE );

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSt_resDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSt_resDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSt_resDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSt_resDlg::OnButton() 
{
	// TODO: Add your control notification handler code here
	m_edit += "You enter button";
	m_edit += "\r\n";
	UpdateData( FALSE );

}

void CSt_resDlg::OnCheck() 
{
	// TODO: Add your control notification handler code here
	if( m_check == TRUE ) { m_check = FALSE;
	m_edit += "Check box disable";}
			else { m_check = TRUE; 	m_edit += "Check box enable"; }
	m_edit += "\r\n";
	UpdateData( FALSE );
}

void CSt_resDlg::OnRadio() 
{
	// TODO: Add your control notification handler code here
		if( m_radio == FALSE ) { m_radio = TRUE;
	m_edit += "Radio button disable";}
			else { m_radio = FALSE; m_edit += "Radio button enable"; }
	m_edit += "\r\n";
	UpdateData( FALSE );
}


void CSt_resDlg::OnSelchangeCombo() 
{
	// TODO: Add your control notification handler code here
	CString temp;
	m_combo.GetLBText( m_combo.GetCurSel() , temp);
	m_edit += "You choese line : ";
	m_edit += temp;
	m_edit += "\r\n";
	UpdateData( FALSE );
}

void CSt_resDlg::OnUpdateEditText() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_UPDATE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	UpdateData( TRUE );
	m_edit += "You write string : ";
	m_edit += m_text;
	m_edit += "\r\n";
	UpdateData( FALSE );
}

void CSt_resDlg::OnSelchangeList() 
{
	// TODO: Add your control notification handler code here
	CString temp;
	m_list.GetText( m_list.GetCurSel() , temp);
	m_edit += "You choese line : ";
	m_edit += temp;
	m_edit += "\r\n";
	UpdateData( FALSE );
}

void CSt_resDlg::OnOutofmemorySpin(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	UpdateData( TRUE );
	m_spin_value = m_spin.GetPos();
	UpdateData( FALSE );	
	*pResult = 0;
}


void CSt_resDlg::OnDeltaposSpin(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	
	m_spin_value = m_spin.GetPos() - 65536;
	UpdateData( FALSE );
	*pResult = 0;
}

void CSt_resDlg::OnCustomdrawSlider(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	m_progress.SetPos( m_slider.GetPos() );
	UpdateData( FALSE );
	*pResult = 0;
}

void CSt_resDlg::OnReleasedcaptureSlider(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	m_edit += "Slider set release position : ";
	char temp[4];
    itoa( m_slider.GetPos(), temp, 10 );
	m_edit += &temp[0];
	m_edit += "\r\n";
	UpdateData( FALSE );
	*pResult = 0;
}
