; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CSt_resDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "st_res.h"

ClassCount=3
Class1=CSt_resApp
Class2=CSt_resDlg
Class3=CAboutDlg

ResourceCount=3
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDD_ST_RES_DIALOG

[CLS:CSt_resApp]
Type=0
HeaderFile=st_res.h
ImplementationFile=st_res.cpp
Filter=N

[CLS:CSt_resDlg]
Type=0
HeaderFile=st_resDlg.h
ImplementationFile=st_resDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=IDC_TREE

[CLS:CAboutDlg]
Type=0
HeaderFile=st_resDlg.h
ImplementationFile=st_resDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
Class=?
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_ST_RES_DIALOG]
Type=1
Class=CSt_resDlg
ControlCount=18
Control1=IDC_STATIC,static,1342308352
Control2=IDC_EDIT,edit,1353779396
Control3=IDC_STATIC,button,1342177287
Control4=IDC_STATIC,button,1342177287
Control5=IDC_BUTTON,button,1342242816
Control6=IDC_CHECK,button,1342242819
Control7=IDC_RADIO,button,1342177289
Control8=IDC_COMBO,combobox,1344349443
Control9=IDC_STATIC,static,1342308352
Control10=IDC_EDIT_TEXT,edit,1350631552
Control11=IDC_LIST,listbox,1352728835
Control12=IDC_STATIC,static,1342308352
Control13=IDC_STATIC,button,1342177287
Control14=IDC_SPIN,msctls_updown32,1342177488
Control15=IDC_EDIT_SPIN,edit,1350633600
Control16=IDC_STATIC,button,1342177287
Control17=IDC_SLIDER,msctls_trackbar32,1342242821
Control18=IDC_PROGRESS,msctls_progress32,1350565889

