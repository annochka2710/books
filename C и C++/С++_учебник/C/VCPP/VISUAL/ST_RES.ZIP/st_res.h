// st_res.h : main header file for the ST_RES application
//

#if !defined(AFX_ST_RES_H__F7866E65_B79C_11D3_9B0B_0060083232E0__INCLUDED_)
#define AFX_ST_RES_H__F7866E65_B79C_11D3_9B0B_0060083232E0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CSt_resApp:
// See st_res.cpp for the implementation of this class
//

class CSt_resApp : public CWinApp
{
public:
	CSt_resApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSt_resApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSt_resApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ST_RES_H__F7866E65_B79C_11D3_9B0B_0060083232E0__INCLUDED_)
