// st_resDlg.h : header file
//

#if !defined(AFX_ST_RESDLG_H__F7866E67_B79C_11D3_9B0B_0060083232E0__INCLUDED_)
#define AFX_ST_RESDLG_H__F7866E67_B79C_11D3_9B0B_0060083232E0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSt_resDlg dialog

class CSt_resDlg : public CDialog
{
// Construction
public:
	CSt_resDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSt_resDlg)
	enum { IDD = IDD_ST_RES_DIALOG };
	CProgressCtrl	m_progress;
	CSliderCtrl	m_slider;
	CSpinButtonCtrl	m_spin;
	CListBox	m_list;
	CComboBox	m_combo;
	CString	m_edit;
	BOOL	m_check;
	BOOL	m_radio;
	CString	m_text;
	long	m_spin_value;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSt_resDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSt_resDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton();
	afx_msg void OnCheck();
	afx_msg void OnRadio();
	afx_msg void OnSelchangeCombo();
	afx_msg void OnUpdateEditText();
	afx_msg void OnSelchangeList();
	afx_msg void OnOutofmemorySpin(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpin(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCustomdrawSlider(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReleasedcaptureSlider(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ST_RESDLG_H__F7866E67_B79C_11D3_9B0B_0060083232E0__INCLUDED_)
