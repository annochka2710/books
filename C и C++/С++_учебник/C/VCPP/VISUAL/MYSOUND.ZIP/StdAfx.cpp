// stdafx.cpp : source file that includes just the standard includes
//	mysound.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



