// mysound.h : main header file for the MYSOUND application
//

#if !defined(AFX_MYSOUND_H__5FD48325_96A8_11D3_90DA_0060083232E0__INCLUDED_)
#define AFX_MYSOUND_H__5FD48325_96A8_11D3_90DA_0060083232E0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMysoundApp:
// See mysound.cpp for the implementation of this class
//

class CMysoundApp : public CWinApp
{
public:
	CMysoundApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMysoundApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMysoundApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYSOUND_H__5FD48325_96A8_11D3_90DA_0060083232E0__INCLUDED_)
