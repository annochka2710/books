// mysoundDlg.h : header file
//

#if !defined(AFX_MYSOUNDDLG_H__5FD48327_96A8_11D3_90DA_0060083232E0__INCLUDED_)
#define AFX_MYSOUNDDLG_H__5FD48327_96A8_11D3_90DA_0060083232E0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMysoundDlg dialog

class CMysoundDlg : public CDialog
{
// Construction
public:

	CMysoundDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMysoundDlg)
	enum { IDD = IDD_MYSOUND_DIALOG };
	CString	m_sound_name;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMysoundDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMysoundDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton1();
	afx_msg void OnButtonFind();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYSOUNDDLG_H__5FD48327_96A8_11D3_90DA_0060083232E0__INCLUDED_)
