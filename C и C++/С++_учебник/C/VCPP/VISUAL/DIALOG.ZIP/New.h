#if !defined(AFX_NEW_H__F0EAAF52_86D0_11D3_90D4_0060083232E0__INCLUDED_)
#define AFX_NEW_H__F0EAAF52_86D0_11D3_90D4_0060083232E0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// New.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNew dialog

class CNew : public CDialog
{
// Construction
public:
	CNew(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNew)
	enum { IDD = IDD_DIALOG1 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNew)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNew)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NEW_H__F0EAAF52_86D0_11D3_90D4_0060083232E0__INCLUDED_)
