; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CPage1
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "tab_control.h"

ClassCount=6
Class1=CTab_controlApp
Class2=CTab_controlDlg
Class3=CAboutDlg

ResourceCount=8
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDD_TAB_CONTROL_DIALOG
Resource4=IDD_ABOUTBOX (English (U.S.))
Resource5=IDD_PAGE2
Class4=CPage1
Resource6=IDD_TAB_CONTROL_DIALOG (English (U.S.))
Resource7=IDD_PAGE1
Class5=CPage2
Class6=CPage3
Resource8=IDD_PAGE3

[CLS:CTab_controlApp]
Type=0
HeaderFile=tab_control.h
ImplementationFile=tab_control.cpp
Filter=N

[CLS:CTab_controlDlg]
Type=0
HeaderFile=tab_controlDlg.h
ImplementationFile=tab_controlDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=CTab_controlDlg

[CLS:CAboutDlg]
Type=0
HeaderFile=tab_controlDlg.h
ImplementationFile=tab_controlDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg


[DLG:IDD_TAB_CONTROL_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CTab_controlDlg

[DLG:IDD_TAB_CONTROL_DIALOG (English (U.S.))]
Type=1
Class=CTab_controlDlg
ControlCount=1
Control1=IDC_TAB,SysTabControl32,1342177280

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_PAGE1]
Type=1
Class=CPage1
ControlCount=2
Control1=IDC_STATIC,static,1342308352
Control2=IDC_NUM1,edit,1350631552

[CLS:CPage1]
Type=0
HeaderFile=Page1.h
ImplementationFile=Page1.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=CPage1

[DLG:IDD_PAGE2]
Type=1
Class=CPage2
ControlCount=2
Control1=IDC_STATIC,static,1342308352
Control2=IDC_NUM2,edit,1350631552

[CLS:CPage2]
Type=0
HeaderFile=Page2.h
ImplementationFile=Page2.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=CPage2

[DLG:IDD_PAGE3]
Type=1
Class=CPage3
ControlCount=6
Control1=IDC_STATIC,static,1342308352
Control2=IDC_A,edit,1350633600
Control3=IDC_B,edit,1350633600
Control4=IDC_STATIC,static,1342308352
Control5=IDC_RES,edit,1350633600
Control6=IDC_STATIC,static,1342308352

[CLS:CPage3]
Type=0
HeaderFile=Page3.h
ImplementationFile=Page3.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=CPage3

