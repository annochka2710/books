// Page3.cpp : implementation file
//

#include "stdafx.h"
#include "tab_control.h"

#include "tab_controlDlg.h"

#include "Page1.h"
#include "Page2.h"
#include "Page3.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPage3 dialog


CPage3::CPage3(CWnd* pParent /*=NULL*/)
	: CDialog(CPage3::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPage3)
	m_a = 0;
	m_b = 0;
	m_res = 0;
	//}}AFX_DATA_INIT
}


void CPage3::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPage3)
	DDX_Text(pDX, IDC_A, m_a);
	DDX_Text(pDX, IDC_B, m_b);
	DDX_Text(pDX, IDC_RES, m_res);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPage3, CDialog)
	//{{AFX_MSG_MAP(CPage3)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPage3 message handlers


void CPage3::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	
	UpdateData( TRUE );
	CTab_controlDlg* pTemp;
    pTemp = new CTab_controlDlg; 
	
    m_a = pTemp->a;
	m_b = pTemp->b;
    m_res = m_a + m_b;
	
	delete pTemp;

	UpdateData( FALSE );
}



