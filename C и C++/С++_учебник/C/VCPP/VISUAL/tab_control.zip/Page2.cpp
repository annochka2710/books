// Page2.cpp : implementation file
//

#include "stdafx.h"
#include "tab_control.h"

#include "tab_controlDlg.h"


#include "Page2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPage2 dialog


CPage2::CPage2(CWnd* pParent /*=NULL*/)
	: CDialog(CPage2::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPage2)
	m_num2 = 0;
	//}}AFX_DATA_INIT
}


void CPage2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPage2)
	DDX_Text(pDX, IDC_NUM2, m_num2);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPage2, CDialog)
	//{{AFX_MSG_MAP(CPage2)
	ON_EN_CHANGE(IDC_NUM2, OnChangeNum2)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPage2 message handlers

void CPage2::OnChangeNum2() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here

    UpdateData( TRUE );

	CTab_controlDlg* pTemp;
    pTemp = new CTab_controlDlg; 
	
	pTemp->b = m_num2;
  
	delete pTemp;
    UpdateData( FALSE );

}


void CPage2::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	
	CTab_controlDlg* pTemp;
    pTemp = new CTab_controlDlg; 
	
	pTemp->b = m_num2;
  
	delete pTemp;
    UpdateData( FALSE );
}
