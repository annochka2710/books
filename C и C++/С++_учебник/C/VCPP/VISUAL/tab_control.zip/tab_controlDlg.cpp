// tab_controlDlg.cpp : implementation file
//

#include "stdafx.h"
#include "tab_control.h"
#include "tab_controlDlg.h"

#include "Page1.h"
#include "Page2.h"
#include "Page3.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTab_controlDlg dialog

CTab_controlDlg::CTab_controlDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTab_controlDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTab_controlDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTab_controlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTab_controlDlg)
	DDX_Control(pDX, IDC_TAB, m_ctrTab);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTab_controlDlg, CDialog)
	//{{AFX_MSG_MAP(CTab_controlDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB, OnSelchangeTab)
	ON_NOTIFY(TCN_SELCHANGING, IDC_TAB, OnSelchangingTab)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTab_controlDlg message handlers

BOOL CTab_controlDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
TC_ITEM TabItem;
TabItem.mask = TCIF_TEXT;
TabItem.pszText = "�������� 1";
m_ctrTab.InsertItem( 0, &TabItem );
TabItem.pszText = "�������� 2";
m_ctrTab.InsertItem( 1, &TabItem );
TabItem.pszText = "���������";
m_ctrTab.InsertItem( 2, &TabItem );


CPage1* pPage1;
pPage1 = new CPage1; 
TabItem.mask = TCIF_PARAM;
TabItem.lParam = (LPARAM)pPage1; 
m_ctrTab.SetItem(0, &TabItem);
VERIFY(pPage1->Create(CPage1::IDD, &m_ctrTab));
pPage1->SetWindowPos(NULL, 2, 22, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
pPage1->ShowWindow(SW_SHOW); 
    
CPage2* pPage2; 
pPage2 = new CPage2;
TabItem.mask = TCIF_PARAM; 
TabItem.lParam = (LPARAM)pPage2;
m_ctrTab.SetItem(1, &TabItem);
VERIFY(pPage2->Create(CPage2::IDD, &m_ctrTab));
pPage2->SetWindowPos(NULL, 2, 22, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
pPage2->ShowWindow(SW_HIDE); 
    
CPage3* pPage3; 
pPage3 = new CPage3;
TabItem.mask = TCIF_PARAM; 
TabItem.lParam = (LPARAM)pPage3;
m_ctrTab.SetItem(2, &TabItem);
VERIFY(pPage3->Create(CPage3::IDD, &m_ctrTab));
pPage3->SetWindowPos(NULL, 2, 22, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
pPage3->ShowWindow(SW_HIDE);



	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTab_controlDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTab_controlDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTab_controlDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTab_controlDlg::OnSelchangeTab(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here

int nTab = m_ctrTab.GetCurSel(); 
TC_ITEM tci; 
tci.mask = TCIF_PARAM; 

m_ctrTab.GetItem(nTab, &tci); 
ASSERT(tci.lParam); 


CWnd* pWnd = (CWnd *)tci.lParam; 
pWnd->ShowWindow(SW_SHOW); 

	*pResult = 0;
}

void CTab_controlDlg::OnSelchangingTab(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	
int nTab = m_ctrTab.GetCurSel(); 
TC_ITEM tci; 
tci.mask = TCIF_PARAM; 

m_ctrTab.GetItem(nTab, &tci); 
ASSERT(tci.lParam); 

CWnd* pWnd = (CWnd *)tci.lParam; 
pWnd->ShowWindow(SW_HIDE); 


	*pResult = 0;
}

void CTab_controlDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
CWnd* pWnd; 
TC_ITEM tci; 
tci.mask = TCIF_PARAM; 

for ( int i = 2 ; i>= 0 ; i--) 
{ 
m_ctrTab.GetItem(i, &tci); 
ASSERT(tci.lParam); 

pWnd = (CWnd *)tci.lParam; 
pWnd->DestroyWindow(); 
delete pWnd; 
}
}
