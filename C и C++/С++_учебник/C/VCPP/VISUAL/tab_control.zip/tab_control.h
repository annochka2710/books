// tab_control.h : main header file for the TAB_CONTROL application
//

#if !defined(AFX_TAB_CONTROL_H__43FAA775_C748_11D3_9B0D_0060083232E0__INCLUDED_)
#define AFX_TAB_CONTROL_H__43FAA775_C748_11D3_9B0D_0060083232E0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols




/////////////////////////////////////////////////////////////////////////////
// CTab_controlApp:
// See tab_control.cpp for the implementation of this class
//

class CTab_controlApp : public CWinApp
{
public:
	CTab_controlApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTab_controlApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTab_controlApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TAB_CONTROL_H__43FAA775_C748_11D3_9B0D_0060083232E0__INCLUDED_)
