// tab_controlDlg.h : header file
//

#if !defined(AFX_TAB_CONTROLDLG_H__43FAA777_C748_11D3_9B0D_0060083232E0__INCLUDED_)
#define AFX_TAB_CONTROLDLG_H__43FAA777_C748_11D3_9B0D_0060083232E0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTab_controlDlg dialog

class CTab_controlDlg : public CDialog
{
// Construction
public:
	int a, b;
	CTab_controlDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTab_controlDlg)
	enum { IDD = IDD_TAB_CONTROL_DIALOG };
	CTabCtrl	m_ctrTab;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTab_controlDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTab_controlDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelchangeTab(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangingTab(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TAB_CONTROLDLG_H__43FAA777_C748_11D3_9B0D_0060083232E0__INCLUDED_)
