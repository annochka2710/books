// Page1.cpp : implementation file
//

#include "stdafx.h"
#include "tab_control.h"

#include "tab_controlDlg.h"


#include "Page1.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPage1 dialog


CPage1::CPage1(CWnd* pParent /*=NULL*/)
	: CDialog(CPage1::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPage1)
	m_num1 = 0;
	//}}AFX_DATA_INIT
}


void CPage1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPage1)
	DDX_Text(pDX, IDC_NUM1, m_num1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPage1, CDialog)
	//{{AFX_MSG_MAP(CPage1)
	ON_EN_CHANGE(IDC_NUM1, OnChangeNum1)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPage1 message handlers

void CPage1::OnChangeNum1() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here

	UpdateData( TRUE );
	
	CTab_controlDlg* pTemp;
    pTemp = new CTab_controlDlg; 
    
	pTemp->a = m_num1;
    
	delete pTemp;
    UpdateData( FALSE );

}


void CPage1::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	

	CTab_controlDlg* pTemp;
    pTemp = new CTab_controlDlg; 
    
	pTemp->a = m_num1;
   
	delete pTemp;
    UpdateData( FALSE );
}




