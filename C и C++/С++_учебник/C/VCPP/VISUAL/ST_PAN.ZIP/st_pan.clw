; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CSt_panDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "st_pan.h"

ClassCount=3
Class1=CSt_panApp
Class2=CSt_panDlg
Class3=CAboutDlg

ResourceCount=5
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDD_ST_PAN_DIALOG
Resource4=IDD_ABOUTBOX (English (U.S.))
Resource5=IDD_ST_PAN_DIALOG (English (U.S.))

[CLS:CSt_panApp]
Type=0
HeaderFile=st_pan.h
ImplementationFile=st_pan.cpp
Filter=N

[CLS:CSt_panDlg]
Type=0
HeaderFile=st_panDlg.h
ImplementationFile=st_panDlg.cpp
Filter=D
LastObject=CSt_panDlg
BaseClass=CDialog
VirtualFilter=dWC

[CLS:CAboutDlg]
Type=0
HeaderFile=st_panDlg.h
ImplementationFile=st_panDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg


[DLG:IDD_ST_PAN_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CSt_panDlg

[DLG:IDD_ST_PAN_DIALOG (English (U.S.))]
Type=1
Class=CSt_panDlg
ControlCount=4
Control1=IDC_BUTTON1,button,1342242816
Control2=IDC_BUTTON2,button,1342242816
Control3=IDC_BUTTON3,button,1342242816
Control4=IDC_BUTTON4,button,1342242816

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

